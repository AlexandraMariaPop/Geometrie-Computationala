﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace geometrietema
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Graphics grp;
        Bitmap bmp;
        Color backcolor;
        private void Form1_Load(object sender, EventArgs e)
        {
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            grp = Graphics.FromImage(bmp);
            backcolor = Color.Aquamarine;
            grp.Clear(backcolor);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            grp.Clear(backcolor); 
            int xa, ya, xb, yb, xc, yc;
            xa = int.Parse(textBox1.Text);
            ya = int.Parse(textBox2.Text);
            xb = int.Parse(textBox3.Text);
            yb = int.Parse(textBox4.Text);
            xc = int.Parse(textBox5.Text);
            yc = int.Parse(textBox6.Text);
            PointF A = new PointF(xa, ya);
            PointF B = new PointF(xb, yb);
            PointF C = new PointF(xc, yc);

            grp.DrawLine(new Pen(Color.Black, 3), A, B);
            grp.DrawLine(new Pen(Color.Black, 3), A, C);
            grp.DrawLine(new Pen(Color.Black, 3), B, C);


            int mx,my, nx,ny, px,py;
            mx = (xa + xb) / 2;
            my= (ya + yb) / 2;
            nx= (xa + xc) / 2;
            ny=(ya + yc) / 2;
            px= (xc + xb) / 2;
            py= (yc + yb) / 2;
            PointF M = new PointF(mx, my);
            PointF N = new PointF(nx, ny);
            PointF P = new PointF(px, py);

            grp.DrawLine(Pens.Green, C, M);
            grp.DrawLine(Pens.Green, B, N);
            grp.DrawLine(Pens.Green, A, P);

            int gx = (xa + xb + xc) / 3;
            int gy = (ya + yb + yc) / 3;
            PointF CG = new PointF(gx, gy);
            

            Pen p = new Pen(Color.DarkSlateGray, 3);
            grp.DrawEllipse(p, gx - 1, gy - 1, 3, 3);
            pictureBox1.Image = bmp;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            grp.Clear(backcolor);
            int xa, ya, xb, yb, xc, yc;
            xa = int.Parse(textBox1.Text);
            ya = int.Parse(textBox2.Text);
            xb = int.Parse(textBox3.Text);
            yb = int.Parse(textBox4.Text);
            xc = int.Parse(textBox5.Text);
            yc = int.Parse(textBox6.Text);
            PointF A = new PointF(xa, ya);
            PointF B = new PointF(xb, yb);
            PointF C = new PointF(xc, yc);

            grp.DrawLine(new Pen(Color.Black,3), A, B);
            grp.DrawLine(new Pen(Color.Black, 3), A, C);
            grp.DrawLine(new Pen(Color.Black, 3), B, C);

            //bisectoare

            float AB, AC, BC;
            AB = Convert.ToSingle(Math.Sqrt((xb - xa) * (xb - xa) + (yb - ya) * (yb - ya)));
            AC = Convert.ToSingle(Math.Sqrt((xc - xa) * (xc - xa) + (yc - ya) * (yc - ya)));
            BC = Convert.ToSingle(Math.Sqrt((xc - xb) * (xc - xb) + (yc - yb) * (yc - yb)));

            float XbisC = (AC * xb + BC * xa) / (BC + AC);
            float YbisC= (AC * yb + BC * ya) / (BC + AC);
            float XbisB = (AB * xc + BC * xa) / (AB + BC);
            float YbisB = (AB * yc + BC * ya) / (AB + BC);
            float XbisA = (AB * xc + AC * xb) / (AB + AC);
            float YbisA = (AB * yc + AC * yb) / (AB + AC);

            PointF bisA = new PointF(XbisA, YbisA);
            PointF bisB = new PointF(XbisB, YbisB);
            PointF bisC = new PointF(XbisC, YbisC);

            float XI = (AB * xc + AC * xb + BC * xa) / (AB + AC + BC);
            float YI = (AB * yc + AC * yb + BC * ya) / (AB + AC + BC);
            Pen p = new Pen(Color.DarkSlateGray, 3);
            grp.DrawEllipse(p, XI - 1, YI - 1, 3, 4);

            grp.DrawLine(Pens.Black, A, bisA);
            grp.DrawLine(Pens.Black, B, bisB);
            grp.DrawLine(Pens.Black, C, bisC);
            


            pictureBox1.Image = bmp;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            grp.Clear(backcolor);
             int xa, ya, xb, yb, xc, yc;
              xa = int.Parse(textBox1.Text);
              ya = int.Parse(textBox2.Text);
              xb = int.Parse(textBox3.Text);
              yb = int.Parse(textBox4.Text);
              xc = int.Parse(textBox5.Text);
              yc = int.Parse(textBox6.Text);
            
              PointF A1 = new PointF(xa, ya);
              PointF B1 = new PointF(xb, yb);
              PointF C1 = new PointF(xc, yc);

              grp.DrawLine(new Pen(Color.Black, 3), A1, B1);
              grp.DrawLine(new Pen(Color.Black, 3), A1, C1);
              grp.DrawLine(new Pen(Color.Black, 3), B1, C1);
              
            int xA, yA, xB, yB, xC, yC;
            xA = Convert.ToInt32(textBox1.Text);
            yA = Convert.ToInt32(textBox2.Text);
            xB = Convert.ToInt32(textBox3.Text);
            yB = Convert.ToInt32(textBox4.Text);
            xC = Convert.ToInt32(textBox5.Text);
            yC = Convert.ToInt32(textBox6.Text);
            PointF A = new PointF(xA, yA);
            PointF B = new PointF(xB, yB);
            PointF C = new PointF(xC, yC);
           

            double dxC = B.X - A.X;
            double dyC = B.Y - A.Y;
            double magC = Math.Sqrt(dxC * dxC + dyC * dyC);
            dxC /= magC;
            dyC /= magC;
            double lambdaC = (dxC * (C.X - A.X)) + (dyC * (C.Y - A.Y));
            double x4 = (dxC * lambdaC) + A.X;
            double y4 = (dyC * lambdaC) + A.Y;
            grp.DrawLine(Pens.Black, (float)x4, (float)y4, xC, yC);

            double dxB = C.X - A.X;
            double dyB = C.Y - A.Y;
            double magB = Math.Sqrt(dxB * dxB + dyB * dyB);
            dxB /= magB;
            dyB /= magB;
            double lambdaB = (dxB * (B.X - A.X)) + (dyB * (B.Y - A.Y));
            double x4B = (dxB * lambdaB) + A.X;
            double y4B = (dyB * lambdaB) + A.Y;
            grp.DrawLine(Pens.Black, (float)x4B, (float)y4B, xB, yB);

            double dxA = C.X - B.X;
            double dyA = C.Y - B.Y;
            double magA = Math.Sqrt(dxA * dxA + dyA * dyA);
            dxA /= magA;
            dyA /= magA;
            double lambdaA = (dxA * (A.X - C.X)) + (dyA * (A.Y - C.Y));
            double x4A = (dxA * lambdaA) + C.X;
            double y4A = (dyA * lambdaA) + C.Y;
            grp.DrawLine(Pens.Black, (float)x4A, (float)y4A, xA, yA);

            float XH2, YH2;
            XH2 =( (xb * (xa - xc) + yb * (ya - yc)) * (yc - yb) - (yc - ya) * (xa * (xb - xc) + ya * (yb - yc)))/ ((xc - xb) * (yc - ya) - (yc - yb) * (xc - xa));

            YH2 = ((xb * (xa - xc) + yb * (ya - yc)) * (xc - xb) - (xc - xa) * (xa * (xb - xc) + ya * (yb - yc))) / ((yc - yb) * (xc - xa) - (xc - xb) * (yc - ya));
            PointF GH2 = new PointF(XH2, YH2);
            grp.DrawEllipse(new Pen(Color.Blue, 4), XH2 - 1, YH2 - 1, 3, 3);
            pictureBox1.Image = bmp;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            grp.Clear(backcolor);
            int xa, ya, xb, yb, xc, yc;
            xa = int.Parse(textBox1.Text);
            ya = int.Parse(textBox2.Text);
            xb = int.Parse(textBox3.Text);
            yb = int.Parse(textBox4.Text);
            xc = int.Parse(textBox5.Text);
            yc = int.Parse(textBox6.Text);
            PointF A = new PointF(xa, ya);
            PointF B = new PointF(xb, yb);
            PointF C = new PointF(xc, yc);

            grp.DrawLine(new Pen(Color.Black, 3), A, B);
            grp.DrawLine(new Pen(Color.Black, 3), A, C);
            grp.DrawLine(new Pen(Color.Black, 3), B, C);

           /* float mxAB, myAB, mxAC, myAC, mxBC, myBC;
            mxAB = (xa + xb) / 2;
            myAB = (ya + yb) / 2;
            mxAC = (xa + xc) / 2;
            myAC = (ya + yc) / 2;
            mxBC = (xc + xb) / 2;
            myBC = (yc + yb) / 2;
            PointF mijAB = new PointF(mxAB, myAB);
            PointF mijAC = new PointF(mxAC, myAC);
            PointF mijBC = new PointF(mxBC, myBC);

            float xcentru, ycentru;
            xcentru = ((xa * xa + ya * ya - xb * xb - yb * yb) * (ya - yc) - (xa * xa + ya * ya - xc * xc - yc * yc) * (ya - yb)) / (2 * (xa - xb) * (ya * yc) - 2 * (xa - xc) * (ya - yb));
            ycentru = ((xa * xa + ya * ya - xc * xc - yc * yc) * (xa - xb) - (xa * xa + ya * ya - xb * xb - yb * yb) * (xa - xc)) / (2 * (xa - xb) * (ya * yc) - 2 * (xa - xc) * (ya - yb));
            PointF CENTRU = new PointF(xcentru, ycentru);
            grp.DrawEllipse(new Pen(Color.Black, 3), xcentru - 1, ycentru - 1, 3, 3);

            grp.DrawLine(Pens.Black, mijAB, CENTRU);
            grp.DrawLine(Pens.Black, mijAC, CENTRU);
            grp.DrawLine(Pens.Black, mijBC, CENTRU); */


            // mijlocul cercului (x,y)
            double d = 2 * (xa * (yb - yc) + xb * (yc - ya) + xc * (ya - yb));

            double s1 = (Math.Pow(xa, 2) + Math.Pow(ya, 2)) * (yb - yc);
            double s2 = (Math.Pow(xb, 2) + Math.Pow(yb, 2)) * (yc - ya);
            double s3 = (Math.Pow(xc, 2) + Math.Pow(yc, 2)) * (ya - yb);
            double Ux = 1 / d * (s1 + s2 + s3);

            double s4 = (Math.Pow(xa, 2) + Math.Pow(ya, 2)) * (xc - xb);
            double s5 = (Math.Pow(xb, 2) + Math.Pow(yb, 2)) * (xa - xc);
            double s6 = (Math.Pow(xc, 2) + Math.Pow(yc, 2)) * (xb - xa);
            double Uy = 1 / d * (s4 + s5 + s6);

            // diametrul cercului
            double dAC = Convert.ToSingle(Math.Sqrt((xa - xc) * (xa - xc) + (ya - yc) * (ya - yc)));
            double dAB = Convert.ToSingle(Math.Sqrt((xa - xb) * (xa - xb) + (ya - yb) * (ya - yb)));
            double dCB = Convert.ToSingle(Math.Sqrt((xc - xb) * (xc - xb) + (yc - yb) * (yc - yb)));

            double dia = 2 * dAC * dAB * dCB / Math.Sqrt((dAC + dAB + dCB) * (dAC - dAB + dCB) * (dAB - dCB + dAC) * (dCB - dAC + dAB));

            // pozitia mediatoarelor pe linie
            PointF mediaA = new PointF((xb + xc) / 2, (yb + yc) / 2);
            PointF mediaB = new PointF((xa + xc) / 2, (ya + yc) / 2);
            PointF mediaC = new PointF((xb + xa) / 2, (yb + ya) / 2);
            PointF PunctO = new PointF(Convert.ToSingle(Ux), Convert.ToSingle(Uy));

            // desenare
            grp.DrawLine(Pens.Black, mediaA, PunctO);
            grp.DrawLine(Pens.Black, mediaB, PunctO);
            grp.DrawLine(Pens.Black, mediaC, PunctO);

            SolidBrush darkCyanBrush = new SolidBrush(Color.DarkCyan);
            grp.DrawEllipse(Pens.DarkCyan, Convert.ToSingle(Ux-dia/2), Convert.ToSingle(Uy-dia/2), Convert.ToSingle(dia), Convert.ToSingle(dia));
            grp.FillEllipse(darkCyanBrush, Convert.ToSingle(Ux-4), Convert.ToSingle(Uy-4), 8, 8);

            pictureBox1.Image = bmp;

        }
    }
}
